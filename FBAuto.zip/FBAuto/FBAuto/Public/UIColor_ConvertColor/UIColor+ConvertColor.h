//
//  UIColor+ConvertColor.h
//  NewChannelInternal
//
//  Created by Lichaowei on 13-11-13.
//  Copyright (c) 2013年 李 沛然. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (ConvertColor)
+ (UIColor *) colorWithHexString: (NSString *)color;
@end
