//
//  ZoomImageView.h
//  TestImageAlbum
//
//  Created by lichaowei on 14-6-23.
//  Copyright (c) 2014年 lcw. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZoomScrollView : UIScrollView<UIScrollViewDelegate>

@property (nonatomic,retain)UIImageView *imageView;

@end
