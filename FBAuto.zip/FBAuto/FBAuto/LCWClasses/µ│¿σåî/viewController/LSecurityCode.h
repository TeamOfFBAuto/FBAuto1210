//
//  LSecurityCode.h
//  FBAuto
//
//  Created by lichaowei on 15/1/8.
//  Copyright (c) 2015年 szk. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LSecurityCode : NSObject
{
    UIButton *codeButton;
    
    UILabel *codeLabel;
    
    NSTimer *timer;
}

@end
