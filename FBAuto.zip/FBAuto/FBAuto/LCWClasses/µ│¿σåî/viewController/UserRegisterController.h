//
//  UserRegisterController.h
//  FBAuto
//
//  Created by lichaowei on 15/1/7.
//  Copyright (c) 2015年 szk. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 *  注册
 */
@interface UserRegisterController : UIViewController



@end
