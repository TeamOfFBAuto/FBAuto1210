//
//  LImageButton.h
//  FBAuto
//
//  Created by lichaowei on 14-7-24.
//  Copyright (c) 2014年 szk. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *  自定义button,上面图片下面文字
 */
@interface LImageButton : UIView

@end
