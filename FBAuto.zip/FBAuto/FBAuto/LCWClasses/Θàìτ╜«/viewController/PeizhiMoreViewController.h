//
//  PeizhiMoreViewController.h
//  FBAuto
//
//  Created by lichaowei on 15/1/22.
//  Copyright (c) 2015年 szk. All rights reserved.
//

#import "FBBaseViewController.h"
/**
 *  更多配置
 */



@interface PeizhiMoreViewController : FBBaseViewController
{
    
}

@property(nonatomic,assign)int pid;//父级id
@property(nonatomic,assign)NSMutableArray *idsArray;


@end
