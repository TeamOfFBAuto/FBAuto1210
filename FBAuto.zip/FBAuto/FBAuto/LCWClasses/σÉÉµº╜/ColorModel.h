//
//  ColorModel.h
//  FBAuto
//
//  Created by lichaowei on 15/1/8.
//  Copyright (c) 2015年 szk. All rights reserved.
//

#import <Foundation/Foundation.h>
/**
 *  吐槽随机颜色
 */
@interface ColorModel : NSObject

+ (UIColor *)colorForTucao:(int)colorid;

@end
