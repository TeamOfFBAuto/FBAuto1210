//
//  TucaoModel.m
//  FBAuto
//
//  Created by lichaowei on 14/12/26.
//  Copyright (c) 2014年 szk. All rights reserved.
//

#import "TucaoModel.h"

@implementation TucaoModel

@end
