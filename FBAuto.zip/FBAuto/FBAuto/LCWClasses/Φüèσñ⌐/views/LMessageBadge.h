//
//  LMessageBadge.h
//  FBAuto
//
//  Created by lichaowei on 14-7-31.
//  Copyright (c) 2014年 szk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LMessageBadge : UIView

@end
