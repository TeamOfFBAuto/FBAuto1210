//
//  FBChatListController.h
//  FBAuto
//
//  Created by lichaowei on 14-10-9.
//  Copyright (c) 2014年 szk. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "RCChatListViewController.h"

@interface FBChatListController : RCChatListViewController

@end
