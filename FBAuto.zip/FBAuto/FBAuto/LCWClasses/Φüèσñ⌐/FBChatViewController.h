//
//  FBChatViewController.h
//  TestIMKIt
//
//  Created by lichaowei on 14-9-20.
//  Copyright (c) 2014年 lcw. All rights reserved.
//

#import "RCChatViewController.h"

@interface FBChatViewController : RCChatViewController

@end
