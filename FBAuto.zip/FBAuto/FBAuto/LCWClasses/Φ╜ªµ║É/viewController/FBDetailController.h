//
//  FBDetailController.h
//  FBAuto
//
//  Created by lichaowei on 14-7-2.
//  Copyright (c) 2014年 szk. All rights reserved.
//

#import "FBBaseViewController.h"
/**
 *  详情
 */

@interface FBDetailController : FBBaseViewController

@property(nonatomic,retain)NSArray *imagesArray;
//@property(nonatomic,retain)UITableView *table;

@end
