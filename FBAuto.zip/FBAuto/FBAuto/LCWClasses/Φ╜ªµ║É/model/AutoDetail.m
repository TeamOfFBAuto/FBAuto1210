//
//  AutoDetail.m
//  FBAuto
//
//  Created by lichaowei on 14-7-3.
//  Copyright (c) 2014年 szk. All rights reserved.
//

#import "AutoDetail.h"

@implementation AutoDetail

@end
