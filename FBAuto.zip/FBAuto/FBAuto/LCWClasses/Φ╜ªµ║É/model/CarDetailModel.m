//
//  CarDetailModel.m
//  FBAuto
//
//  Created by lichaowei on 15/1/29.
//  Copyright (c) 2015年 szk. All rights reserved.
//

#import "CarDetailModel.h"

@implementation CarDetailModel

@end
