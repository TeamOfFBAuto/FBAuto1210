//
//  CarStyle.m
//  FBAuto
//
//  Created by lichaowei on 14-7-15.
//  Copyright (c) 2014年 szk. All rights reserved.
//

#import "CarStyle.h"


@implementation CarStyle

@dynamic parentId;
@dynamic styleId;
@dynamic styleName;

@end
