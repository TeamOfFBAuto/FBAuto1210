//
//  AutoDetail.h
//  FBAuto
//
//  Created by lichaowei on 14-7-3.
//  Copyright (c) 2014年 szk. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AutoDetail : NSObject

@property(nonatomic,retain)NSString *carModel;//车型
@property(nonatomic,retain)NSString *carPrice;
@property(nonatomic,retain)NSString *carTimelimit;
@property(nonatomic,retain)NSString *carOutColor;
@property(nonatomic,retain)NSString *carInColor;
@property(nonatomic,retain)NSString *carStandard;//版本
@property(nonatomic,retain)NSString *carDate;
@property(nonatomic,retain)NSString *carDetail;

//-(id)initWithModel:

@end
