//
//  CarBrand.m
//  FBAuto
//
//  Created by lichaowei on 14-7-15.
//  Copyright (c) 2014年 szk. All rights reserved.
//

#import "CarBrand.h"


@implementation CarBrand

@dynamic brandId;
@dynamic brandName;
@dynamic brandFirstLetter;


@end
