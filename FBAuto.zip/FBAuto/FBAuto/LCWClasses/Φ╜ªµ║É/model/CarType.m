//
//  CarType.m
//  FBAuto
//
//  Created by lichaowei on 14-7-15.
//  Copyright (c) 2014年 szk. All rights reserved.
//

#import "CarType.h"


@implementation CarType

@dynamic parentId;
@dynamic typeId;
@dynamic typeName;
@dynamic firstLetter;

@end
