//
//  LiuyanModel.m
//  FBAuto
//
//  Created by lichaowei on 15/1/14.
//  Copyright (c) 2015年 szk. All rights reserved.
//

#import "LiuyanModel.h"

@implementation LiuyanModel


@end
