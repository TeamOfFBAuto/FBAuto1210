//
//  LiuyanModel.h
//  FBAuto
//
//  Created by lichaowei on 15/1/14.
//  Copyright (c) 2015年 szk. All rights reserved.
//

#import "BaseModel.h"

@interface LiuyanModel : BaseModel

@property(nonatomic,retain)NSString *id;
@property(nonatomic,retain)NSString *uid;
@property(nonatomic,retain)NSString *username;
@property(nonatomic,retain)NSString *art_uid;
@property(nonatomic,retain)NSString *content;
@property(nonatomic,retain)NSString *ctype;
@property(nonatomic,retain)NSString *dateline;
@property(nonatomic,retain)NSString *isdel;
@property(nonatomic,retain)NSString *head_image;

@end
