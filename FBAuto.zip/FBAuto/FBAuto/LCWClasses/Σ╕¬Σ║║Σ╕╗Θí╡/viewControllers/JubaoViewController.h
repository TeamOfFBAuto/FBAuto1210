//
//  JubaoViewController.h
//  FBAuto
//
//  Created by lichaowei on 15/1/20.
//  Copyright (c) 2015年 szk. All rights reserved.
//

#import "FBBaseViewController.h"

/**
 *  举报view
 */
@interface JubaoViewController : FBBaseViewController

@property(nonatomic,retain)NSString *cid;//车源id

@end
