//
//  LiuyanViewController.h
//  FBAuto
//
//  Created by lichaowei on 15/1/14.
//  Copyright (c) 2015年 szk. All rights reserved.
//

#import "FBBaseViewController.h"

@interface LiuyanViewController : FBBaseViewController

@property(nonatomic,retain)NSString *art_uid;//评论id

@end
