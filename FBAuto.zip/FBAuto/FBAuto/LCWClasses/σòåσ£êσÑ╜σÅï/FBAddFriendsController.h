//
//  FBAddFriendsController.h
//  FBAuto
//
//  Created by lichaowei on 14-7-4.
//  Copyright (c) 2014年 szk. All rights reserved.
//

#import "FBBaseViewController.h"

/**
 *  添加好友
 */
@interface FBAddFriendsController : FBBaseViewController

@end
