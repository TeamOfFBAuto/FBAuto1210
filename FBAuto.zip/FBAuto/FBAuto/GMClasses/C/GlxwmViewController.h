//
//  GlxwmViewController.h
//  FBAuto
//
//  Created by gaomeng on 14-7-10.
//  Copyright (c) 2014年 szk. All rights reserved.
//


//联系我们界面
#import <UIKit/UIKit.h>

@interface GlxwmViewController : FBBaseViewController

@end
