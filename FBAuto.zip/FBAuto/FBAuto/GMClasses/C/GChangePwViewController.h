//
//  GChangePwViewController.h
//  FBAuto
//
//  Created by gaomeng on 14-7-8.
//  Copyright (c) 2014年 szk. All rights reserved.
//

//修改密码界面
#import <UIKit/UIKit.h>

@interface GChangePwViewController : FBBaseViewController<UIAlertViewDelegate>

@property(nonatomic,strong)NSMutableArray *tfArray;//textfield数组

@end
