//
//  GMessageSViewController.h
//  FBAuto
//
//  Created by gaomeng on 14-7-9.
//  Copyright (c) 2014年 szk. All rights reserved.
//

//个人中心 消息设置
#import <UIKit/UIKit.h>

@interface GMessageSViewController : FBBaseViewController


@property(nonatomic,strong)UISwitch *mySwitch;//开关控件

@property(nonatomic,assign)BOOL onOrOff;//开或关  开yes  关no

@end
