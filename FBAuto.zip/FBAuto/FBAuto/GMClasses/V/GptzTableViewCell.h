//
//  GptzTableViewCell.h
//  FBAuto
//
//  Created by gaomeng on 14-7-9.
//  Copyright (c) 2014年 szk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GptzTableViewCell : UITableViewCell

@property(nonatomic,strong)UILabel *timeLabel;//时间label
@property(nonatomic,strong)UILabel *contentLabel;//内容label


@end
